How to Use the Proforma Invoice Generator (Python Script)

1. Make sure you have Python installed on your computer (https://www.python.org).
2. Place all files in the same folder.
3. Open a terminal or command prompt in that folder.
4. Run the script with the command:
   python generate_invoice.py
5. After it runs, a file named 'your_invoice.pdf' will be created in the same folder.

To customize the invoice, simply open 'generate_invoice.py' in any text editor and edit the values under 'invoice_data'.
